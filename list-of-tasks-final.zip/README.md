# list-of-tasks-app

[Edit in StackBlitz next generation editor ⚡️](https://stackblitz.com/~/github.com/johnenosh92/list-of-tasks-app)